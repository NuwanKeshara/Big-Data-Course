
def hello():
    return "Hello, World!"

def send_otp():
    return "OTP sent successfully"



if(__name__ == "__main__"):
    print(__name__)
    print (send_otp())