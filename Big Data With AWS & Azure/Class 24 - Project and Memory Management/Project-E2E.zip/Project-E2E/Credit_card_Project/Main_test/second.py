import Main_test.first 



if(__name__ == "__main__"):
    print(__name__)
    print("Hello World")