

def drop_na(df,how):
    return df.dropna(how=how)

